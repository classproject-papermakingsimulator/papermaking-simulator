<template>
  <div id="main" :style="{backgroundImage:'url('+require('../assets/images/red-panda.jpg')+')'}">
    <div>
      <div >
        <div class="nav-sub ">
          <div class="nav-sub-wrapper">
            <div class="container">
              <ul class="nav-list">
                <input @change="uploadPhoto($event)" type="file" class="kyc-passin item-blue-btn">
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="sku-box store-content " style="width: 90%" >
      <div class="gray-box">
        <header class="title-header">
          <h5 class="title">作品展示&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5>
        </header>
        <div class="item-box">
          <div class="item">
            <div>
              <div class="item-img"><img  :src="imgfile" style="opacity: 1;">
              </div>
              <h6>用户名：</h6>
              <h3 >用户ID：</h3>
              <div class="discount-icon">false</div>
              <div class="item-cover">
                <a href="javascript:;" target="_blank"></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import '../assets/css/header.css'
import '../assets/css/reset.css'
import '../assets/css/goodsList.css'
export default {
  name: 'Paper',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      imgfile: 'http://localhost:8080/api/show?num=0'
    }
  },
  methods: {
    uploadPhoto (e) {
      let file = e.target.files[0]
      let newfile = new File([file], 'BlackAngle.jpg', {
        type: file.type})
      let formData = new FormData()
      formData.append('file', newfile)
      this.axios.post('/api/share', formData)
        .then((response) => {
        })
        .catch((error) => {
          alert(error)
        })
      this.imgfile = 'http://localhost:8080/api/show?num=0'
    }
  }
}
</script>

<style scoped>
  .nav-goods-panel{
    height: 350px;
    position: relative;
    overflow: hidden;
    background: #E7E7E7;
    opacity: 0;
  }
  .active .nav-goods-panel{
    height: 350px;
    position: relative;
    overflow: hidden;
    background: #E7E7E7;
    opacity: 1;
  }
  .nav-goods-list{
    visibility: visible;
    opacity: 1;
    width: 95%;
    height: 270px;
    padding-top: 52px;
    text-align: center;
  }
  .nav-goods-list li{

    position: relative;
    display: inline-block;
    vertical-align: top;

    height: 260px;
    font-size: 14px;
  }

  .main{
    background-image :url(../assets/images/bamboo1.jpg);
  }
</style>
